 /**
Licensed Materials - Property of IBM 
5724-O03
Copyright IBM Corp. 2013.
US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

The Program may contain sample source code or programs, which illustrate programming techniques. 
You may only copy, modify, and distribute these samples internally. 
These samples have not been tested under all conditions and are provided to you by IBM without obligation of support of any kind.

IBM PROVIDES THESE SAMPLES "AS IS" SUBJECT TO ANY STATUTORY WARRANTIES THAT CANNOT BE EXCLUDED.
IBM MAKES NO WARRANTIES OR CONDITIONS, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
AND NON-INFRINGEMENT REGARDING THESE SAMPLES OR TECHNICAL SUPPORT, IF ANY.
*/

$().ready(function() { $( "#jQuerySimpleTabsSample" ).tabs();});
